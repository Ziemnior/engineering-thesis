class ConnectionError(Exception):
    pass


class InterfaceError(Exception):
    pass
